# Hidato
Hidato game for PROP subject in Facultat d'Informàtica de Barcelona. 2017-2018 Q2
