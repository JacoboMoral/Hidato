package main.domain.com.hidato;
public enum TipusAdjacencia {
    COSTATS,
    COSTATSIANGLES;
}
