package main.domain.com.hidato;
public enum TipusCella {
    TRIANGLE,
    QUADRAT,
    HEXAGON;
}
