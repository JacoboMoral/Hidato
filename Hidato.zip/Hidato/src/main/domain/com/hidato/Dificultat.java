package main.domain.com.hidato;
public enum Dificultat {
    FACIL,
    MIG,
    DIFICIL;
}
