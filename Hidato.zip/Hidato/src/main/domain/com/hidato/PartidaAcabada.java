package main.domain.com.hidato;

public class PartidaAcabada {

}
